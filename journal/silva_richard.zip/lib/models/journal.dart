class Journal {
  List<dynamic> entries = [];

  Journal({required this.entries});
}
