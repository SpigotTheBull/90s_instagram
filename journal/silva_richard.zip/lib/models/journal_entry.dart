class JournalEntry {
  late String? title;
  late String? body;
  late DateTime? date;
  late int? rating;

  JournalEntry({this.title, this.body, this.date, this.rating});
}
